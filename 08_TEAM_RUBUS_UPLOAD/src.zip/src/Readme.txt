The testcases of our group are provided as single .c files, but they are also already 
included in the main file, so that the special testcase just needs to be uncommented. 

The adopted (executable) Testcases from the other groups are also provided as comments 
in the main.c file.